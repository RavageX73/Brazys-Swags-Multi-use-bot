package club.minnced.discord.webhook;

public class LibraryInfo {
	public static final int DISCORD_API_VERSION = 7;
	public static final String VERSION_MAJOR = "0";
	public static final String VERSION_MINOR = "1";
	public static final String VERSION_PATCH = "7";
	public static final String VERSION = "0.1.7";
}