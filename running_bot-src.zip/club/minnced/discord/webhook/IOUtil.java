package club.minnced.discord.webhook;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;
import okhttp3.MediaType;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;
import org.json.JSONTokener;

public class IOUtil {
	public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
	public static final MediaType OCTET = MediaType.parse("application/octet-stream; charset=utf-8");
	public static final byte[] EMPTY_BYTES = new byte[0];
	private static final CompletableFuture[] EMPTY_FUTURES = new CompletableFuture[0];

	@NotNull
	public static byte[] readAllBytes(@NotNull InputStream stream) throws IOException {
		int count = false;
		int pos = 0;
		byte[] output = EMPTY_BYTES;
		byte[] buf = new byte[1024];

		int count;
		while ((count = stream.read(buf)) > 0) {
			if (pos + count >= output.length) {
				byte[] tmp = output;
				output = new byte[pos + count];
				System.arraycopy(tmp, 0, output, 0, tmp.length);
			}

			for (int i = 0; i < count; ++i) {
				output[pos++] = buf[i];
			}
		}

		return output;
	}

	@Nullable
	public static InputStream getBody(@NotNull Response req) throws IOException {
		List<String> encoding = req.headers("content-encoding");
		ResponseBody body = req.body();
		if (!encoding.isEmpty() && body != null) {
			return new GZIPInputStream(body.byteStream());
		} else {
			return body != null ? body.byteStream() : null;
		}
	}

	@NotNull
	public static JSONObject toJSON(@NotNull InputStream input) {
		return new JSONObject(new JSONTokener(input));
	}

	@NotNull
	public static <T> CompletableFuture<List<T>> flipFuture(@NotNull List<CompletableFuture<T>> list) {
		List<T> result = new ArrayList(list.size());
		List<CompletableFuture<Void>> updatedStages = new ArrayList(list.size());
		Stream var10000 = list.stream().map((it) -> {
			Objects.requireNonNull(result);
			return it.thenAccept(result::add);
		});
		Objects.requireNonNull(updatedStages);
		var10000.forEach(updatedStages::add);
		CompletableFuture<Void> tracker = CompletableFuture
				.allOf((CompletableFuture[]) updatedStages.toArray(EMPTY_FUTURES));
		CompletableFuture<List<T>> future = new CompletableFuture();
		tracker.thenRun(() -> {
			future.complete(result);
		}).exceptionally((e) -> {
			future.completeExceptionally(e);
			return null;
		});
		return future;
	}
}