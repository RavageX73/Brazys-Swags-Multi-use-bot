package club.minnced.discord.webhook.receive;

import club.minnced.discord.webhook.receive.ReadonlyEmbed.EmbedImage;
import club.minnced.discord.webhook.receive.ReadonlyEmbed.EmbedProvider;
import club.minnced.discord.webhook.receive.ReadonlyEmbed.EmbedVideo;
import club.minnced.discord.webhook.send.WebhookEmbed.EmbedAuthor;
import club.minnced.discord.webhook.send.WebhookEmbed.EmbedField;
import club.minnced.discord.webhook.send.WebhookEmbed.EmbedFooter;
import club.minnced.discord.webhook.send.WebhookEmbed.EmbedTitle;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.json.JSONArray;
import org.json.JSONObject;

public class EntityFactory {
	@NotNull
	public static ReadonlyUser makeUser(@NotNull JSONObject json) {
		long id = Long.parseUnsignedLong(json.getString("id"));
		String name = json.getString("username");
		String avatar = json.optString("avatar", (String) null);
		short discriminator = Short.parseShort(json.getString("discriminator"));
		boolean bot = !json.isNull("bot") && json.getBoolean("bot");
		return new ReadonlyUser(id, discriminator, bot, name, avatar);
	}

	@NotNull
	public static ReadonlyAttachment makeAttachment(@NotNull JSONObject json) {
		String url = json.getString("url");
		String proxy = json.getString("proxy_url");
		String name = json.getString("filename");
		int size = json.getInt("size");
		int width = json.optInt("width", -1);
		int height = json.optInt("height", -1);
		long id = Long.parseUnsignedLong(json.getString("id"));
		return new ReadonlyAttachment(url, proxy, name, width, height, size, id);
	}

	@Nullable
	public static EmbedField makeEmbedField(@Nullable JSONObject json) {
		if (json == null) {
			return null;
		} else {
			String name = json.getString("name");
			String value = json.getString("value");
			boolean inline = !json.isNull("inline") && json.getBoolean("inline");
			return new EmbedField(inline, name, value);
		}
	}

	@Nullable
	public static EmbedAuthor makeEmbedAuthor(@Nullable JSONObject json) {
		if (json == null) {
			return null;
		} else {
			String name = json.getString("name");
			String url = json.optString("url", (String) null);
			String icon = json.optString("icon_url", (String) null);
			return new EmbedAuthor(name, icon, url);
		}
	}

	@Nullable
	public static EmbedFooter makeEmbedFooter(@Nullable JSONObject json) {
		if (json == null) {
			return null;
		} else {
			String text = json.getString("text");
			String icon = json.optString("icon_url", (String) null);
			return new EmbedFooter(text, icon);
		}
	}

	@Nullable
	public static EmbedTitle makeEmbedTitle(@NotNull JSONObject json) {
		String text = json.optString("title", (String) null);
		if (text == null) {
			return null;
		} else {
			String url = json.optString("url", (String) null);
			return new EmbedTitle(text, url);
		}
	}

	@Nullable
	public static EmbedImage makeEmbedImage(@Nullable JSONObject json) {
		if (json == null) {
			return null;
		} else {
			String url = json.getString("url");
			String proxyUrl = json.getString("proxy_url");
			int width = json.getInt("width");
			int height = json.getInt("height");
			return new EmbedImage(url, proxyUrl, width, height);
		}
	}

	@Nullable
	public static EmbedProvider makeEmbedProvider(@Nullable JSONObject json) {
		if (json == null) {
			return null;
		} else {
			String url = json.getString("url");
			String name = json.getString("name");
			return new EmbedProvider(name, url);
		}
	}

	@Nullable
	public static EmbedVideo makeEmbedVideo(@Nullable JSONObject json) {
		if (json == null) {
			return null;
		} else {
			String url = json.getString("url");
			int height = json.getInt("height");
			int width = json.getInt("width");
			return new EmbedVideo(url, width, height);
		}
	}

	@NotNull
	public static ReadonlyEmbed makeEmbed(@NotNull JSONObject json) {
		String description = json.optString("description", (String) null);
		Integer color = json.isNull("color") ? null : json.getInt("color");
		EmbedImage image = makeEmbedImage(json.optJSONObject("image"));
		EmbedImage thumbnail = makeEmbedImage(json.optJSONObject("thumbnail"));
		EmbedProvider provider = makeEmbedProvider(json.optJSONObject("provider"));
		EmbedVideo video = makeEmbedVideo(json.optJSONObject("video"));
		EmbedFooter footer = makeEmbedFooter(json.optJSONObject("footer"));
		EmbedAuthor author = makeEmbedAuthor(json.optJSONObject("author"));
		EmbedTitle title = makeEmbedTitle(json);
		OffsetDateTime timestamp;
		if (json.isNull("timestamp")) {
			timestamp = null;
		} else {
			timestamp = OffsetDateTime.parse(json.getString("timestamp"));
		}

		JSONArray fieldArray = json.optJSONArray("fields");
		List<EmbedField> fields = new ArrayList();
		if (fieldArray != null) {
			for (int i = 0; i < fieldArray.length(); ++i) {
				JSONObject obj = fieldArray.getJSONObject(i);
				EmbedField field = makeEmbedField(obj);
				if (field != null) {
					fields.add(field);
				}
			}
		}

		return new ReadonlyEmbed(timestamp, color, description, thumbnail, image, footer, title, author, fields,
				provider, video);
	}

	@NotNull
	public static ReadonlyMessage makeMessage(@NotNull JSONObject json) {
		long id = Long.parseUnsignedLong(json.getString("id"));
		long channelId = Long.parseUnsignedLong(json.getString("channel_id"));
		ReadonlyUser author = makeUser(json.getJSONObject("author"));
		String content = json.getString("content");
		boolean tts = json.getBoolean("tts");
		boolean mentionEveryone = json.getBoolean("mention_everyone");
		JSONArray usersArray = json.getJSONArray("mentions");
		JSONArray rolesArray = json.getJSONArray("mention_roles");
		JSONArray embedArray = json.getJSONArray("embeds");
		JSONArray attachmentArray = json.getJSONArray("attachments");
		List<ReadonlyUser> mentionedUsers = convertToList(usersArray, EntityFactory::makeUser);
		List<ReadonlyEmbed> embeds = convertToList(embedArray, EntityFactory::makeEmbed);
		List<ReadonlyAttachment> attachments = convertToList(attachmentArray, EntityFactory::makeAttachment);
		List<Long> mentionedRoles = new ArrayList();

		for (int i = 0; i < rolesArray.length(); ++i) {
			mentionedRoles.add(Long.parseUnsignedLong(rolesArray.getString(i)));
		}

		return new ReadonlyMessage(id, channelId, mentionEveryone, tts, author, content, embeds, attachments,
				mentionedUsers, mentionedRoles);
	}

	private static <T> List<T> convertToList(JSONArray arr, Function<JSONObject, T> converter) {
		if (arr == null) {
			return Collections.emptyList();
		} else {
			List<T> list = new ArrayList();

			for (int i = 0; i < arr.length(); ++i) {
				JSONObject json = arr.getJSONObject(i);
				T out = converter.apply(json);
				if (out != null) {
					list.add(out);
				}
			}

			return Collections.unmodifiableList(list);
		}
	}
}