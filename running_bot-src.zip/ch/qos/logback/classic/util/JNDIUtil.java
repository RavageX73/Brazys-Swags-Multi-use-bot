package ch.qos.logback.classic.util;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class JNDIUtil {
	public static Context getInitialContext() throws NamingException {
		return new InitialContext();
	}

	public static String lookup(Context ctx, String name) {
		if (ctx == null) {
			return null;
		} else {
			try {
				Object lookup = ctx.lookup(name);
				return lookup == null ? null : lookup.toString();
			} catch (NamingException var3) {
				return null;
			}
		}
	}
}