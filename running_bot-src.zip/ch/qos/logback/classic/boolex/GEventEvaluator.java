package ch.qos.logback.classic.boolex;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.boolex.EvaluationException;
import ch.qos.logback.core.boolex.EventEvaluatorBase;
import ch.qos.logback.core.util.FileUtil;
import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyObject;
import groovy.lang.Script;
import org.codehaus.groovy.control.CompilationFailedException;

public class GEventEvaluator extends EventEvaluatorBase<ILoggingEvent> {
	String expression;
	IEvaluator delegateEvaluator;
	Script script;

	public String getExpression() {
		return this.expression;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public void start() {
		int errors = 0;
		if (this.expression != null && this.expression.length() != 0) {
			this.addInfo("Expression to evaluate [" + this.expression + "]");
			ClassLoader classLoader = this.getClass().getClassLoader();
			String currentPackageName = this.getClass().getPackage().getName();
			currentPackageName = currentPackageName.replace('.', '/');
			FileUtil fileUtil = new FileUtil(this.getContext());
			String scriptText = fileUtil.resourceAsString(classLoader,
					currentPackageName + "/EvaluatorTemplate.groovy");
			if (scriptText != null) {
				scriptText = scriptText.replace("//EXPRESSION", this.expression);
				GroovyClassLoader gLoader = new GroovyClassLoader(classLoader);

				try {
					Class scriptClass = gLoader.parseClass(scriptText);
					GroovyObject goo = (GroovyObject) scriptClass.newInstance();
					this.delegateEvaluator = (IEvaluator) goo;
				} catch (CompilationFailedException var9) {
					this.addError("Failed to compile expression [" + this.expression + "]", var9);
					++errors;
				} catch (Exception var10) {
					this.addError("Failed to compile expression [" + this.expression + "]", var10);
					++errors;
				}

				if (errors == 0) {
					super.start();
				}

			}
		} else {
			this.addError("Empty expression");
		}
	}

	public boolean evaluate(ILoggingEvent event) throws NullPointerException, EvaluationException {
		return this.delegateEvaluator == null ? false : this.delegateEvaluator.doEvaluate(event);
	}
}