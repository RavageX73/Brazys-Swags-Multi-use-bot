package ch.qos.logback.classic.pattern;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.pattern.DynamicConverter;

public abstract class ClassicConverter extends DynamicConverter<ILoggingEvent> {
}