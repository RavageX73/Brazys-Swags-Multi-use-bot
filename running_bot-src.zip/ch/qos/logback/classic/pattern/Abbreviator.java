package ch.qos.logback.classic.pattern;

public interface Abbreviator {
	String abbreviate(String var1);
}