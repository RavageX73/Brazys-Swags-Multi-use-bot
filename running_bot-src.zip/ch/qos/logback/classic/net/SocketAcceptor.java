package ch.qos.logback.classic.net;

class SocketAcceptor extends Thread {
	public void run() {
	}
}