package ch.qos.logback.classic.turbo;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.turbo.ReconfigureOnChangeFilter.ReconfiguringThread;
import ch.qos.logback.core.joran.spi.ConfigurationWatchList;
import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;
import ch.qos.logback.core.spi.FilterReply;
import java.io.File;
import java.net.URL;
import java.util.List;
import org.slf4j.Marker;

public class ReconfigureOnChangeFilter extends TurboFilter {
	public static final long DEFAULT_REFRESH_PERIOD = 60000L;
	long refreshPeriod = 60000L;
	URL mainConfigurationURL;
	protected volatile long nextCheck;
	ConfigurationWatchList configurationWatchList;
	private long invocationCounter = 0L;
	private volatile long mask = 15L;
	private volatile long lastMaskCheck = System.currentTimeMillis();
	private static final int MAX_MASK = 65535;
	private static final long MASK_INCREASE_THRESHOLD = 100L;
	private static final long MASK_DECREASE_THRESHOLD = 800L;

	public void start() {
		this.configurationWatchList = ConfigurationWatchListUtil.getConfigurationWatchList(this.context);
		if (this.configurationWatchList != null) {
			this.mainConfigurationURL = this.configurationWatchList.getMainURL();
			if (this.mainConfigurationURL == null) {
				this.addWarn("Due to missing top level configuration file, automatic reconfiguration is impossible.");
				return;
			}

			List<File> watchList = this.configurationWatchList.getCopyOfFileWatchList();
			long inSeconds = this.refreshPeriod / 1000L;
			this.addInfo("Will scan for changes in [" + watchList + "] every " + inSeconds + " seconds. ");
			ConfigurationWatchList var4 = this.configurationWatchList;
			synchronized (this.configurationWatchList) {
				this.updateNextCheck(System.currentTimeMillis());
			}

			super.start();
		} else {
			this.addWarn("Empty ConfigurationWatchList in context");
		}

	}

	public String toString() {
		return "ReconfigureOnChangeFilter{invocationCounter=" + this.invocationCounter + '}';
	}

	public FilterReply decide(Marker marker, Logger logger, Level level, String format, Object[] params, Throwable t) {
		if (!this.isStarted()) {
			return FilterReply.NEUTRAL;
		} else if ((this.invocationCounter++ & this.mask) != this.mask) {
			return FilterReply.NEUTRAL;
		} else {
			long now = System.currentTimeMillis();
			ConfigurationWatchList var9 = this.configurationWatchList;
			synchronized (this.configurationWatchList) {
				this.updateMaskIfNecessary(now);
				if (this.changeDetected(now)) {
					this.disableSubsequentReconfiguration();
					this.detachReconfigurationToNewThread();
				}
			}

			return FilterReply.NEUTRAL;
		}
	}

	private void updateMaskIfNecessary(long now) {
		long timeElapsedSinceLastMaskUpdateCheck = now - this.lastMaskCheck;
		this.lastMaskCheck = now;
		if (timeElapsedSinceLastMaskUpdateCheck < 100L && this.mask < 65535L) {
			this.mask = this.mask << 1 | 1L;
		} else if (timeElapsedSinceLastMaskUpdateCheck > 800L) {
			this.mask >>>= 2;
		}

	}

	void detachReconfigurationToNewThread() {
		this.addInfo("Detected change in [" + this.configurationWatchList.getCopyOfFileWatchList() + "]");
		this.context.getExecutorService().submit(new ReconfiguringThread(this));
	}

	void updateNextCheck(long now) {
		this.nextCheck = now + this.refreshPeriod;
	}

	protected boolean changeDetected(long now) {
		if (now >= this.nextCheck) {
			this.updateNextCheck(now);
			return this.configurationWatchList.changeDetected();
		} else {
			return false;
		}
	}

	void disableSubsequentReconfiguration() {
		this.nextCheck = Long.MAX_VALUE;
	}

	public long getRefreshPeriod() {
		return this.refreshPeriod;
	}

	public void setRefreshPeriod(long refreshPeriod) {
		this.refreshPeriod = refreshPeriod;
	}
}