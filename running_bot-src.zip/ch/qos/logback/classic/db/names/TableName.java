package ch.qos.logback.classic.db.names;

public enum TableName {
	LOGGING_EVENT, LOGGING_EVENT_PROPERTY, LOGGING_EVENT_EXCEPTION;
}