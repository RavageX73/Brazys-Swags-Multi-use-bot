package ch.qos.logback.classic.gaffer;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.status.ErrorStatus;
import ch.qos.logback.core.status.StatusManager;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;

public class GafferUtil {
	private static String ERROR_MSG = "Failed to instantiate ch.qos.logback.classic.gaffer.GafferConfigurator";

	public static void runGafferConfiguratorOn(LoggerContext loggerContext, Object origin, File configFile) {
		GafferConfigurator gafferConfigurator = newGafferConfiguratorInstance(loggerContext, origin);
		if (gafferConfigurator != null) {
			gafferConfigurator.run(configFile);
		}

	}

	public static void runGafferConfiguratorOn(LoggerContext loggerContext, Object origin, URL configFile) {
		GafferConfigurator gafferConfigurator = newGafferConfiguratorInstance(loggerContext, origin);
		if (gafferConfigurator != null) {
			gafferConfigurator.run(configFile);
		}

	}

	private static GafferConfigurator newGafferConfiguratorInstance(LoggerContext loggerContext, Object origin) {
		try {
			Class gcClass = Class.forName("ch.qos.logback.classic.gaffer.GafferConfigurator");
			Constructor c = gcClass.getConstructor(LoggerContext.class);
			return (GafferConfigurator) c.newInstance(loggerContext);
		} catch (ClassNotFoundException var4) {
			addError(loggerContext, origin, ERROR_MSG, var4);
		} catch (NoSuchMethodException var5) {
			addError(loggerContext, origin, ERROR_MSG, var5);
		} catch (InvocationTargetException var6) {
			addError(loggerContext, origin, ERROR_MSG, var6);
		} catch (InstantiationException var7) {
			addError(loggerContext, origin, ERROR_MSG, var7);
		} catch (IllegalAccessException var8) {
			addError(loggerContext, origin, ERROR_MSG, var8);
		}

		return null;
	}

	private static void addError(LoggerContext context, Object origin, String msg) {
		addError(context, origin, msg, (Throwable) null);
	}

	private static void addError(LoggerContext context, Object origin, String msg, Throwable t) {
		StatusManager sm = context.getStatusManager();
		if (sm != null) {
			sm.add(new ErrorStatus(msg, origin, t));
		}
	}
}