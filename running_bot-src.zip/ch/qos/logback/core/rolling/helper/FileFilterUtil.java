package ch.qos.logback.core.rolling.helper;

import ch.qos.logback.core.rolling.helper.FileFilterUtil.1;
import ch.qos.logback.core.rolling.helper.FileFilterUtil.2;
import ch.qos.logback.core.rolling.helper.FileFilterUtil.3;
import java.io.File;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileFilterUtil {
	public static void sortFileArrayByName(File[] fileArray) {
      Arrays.sort(fileArray, new 1());
   }

	public static void reverseSortFileArrayByName(File[] fileArray) {
      Arrays.sort(fileArray, new 2());
   }

	public static String afterLastSlash(String sregex) {
		int i = sregex.lastIndexOf(47);
		return i == -1 ? sregex : sregex.substring(i + 1);
	}

	public static boolean isEmptyDirectory(File dir) {
		if (!dir.isDirectory()) {
			throw new IllegalArgumentException("[" + dir + "] must be a directory");
		} else {
			String[] filesInDir = dir.list();
			return filesInDir == null || filesInDir.length == 0;
		}
	}

	public static File[] filesInFolderMatchingStemRegex(File file, String stemRegex) {
      if (file == null) {
         return new File[0];
      } else {
         return file.exists() && file.isDirectory() ? file.listFiles(new 3(stemRegex)) : new File[0];
      }
   }

	public static int findHighestCounter(File[] matchingFileArray, String stemRegex) {
		int max = Integer.MIN_VALUE;
		File[] arr$ = matchingFileArray;
		int len$ = matchingFileArray.length;

		for (int i$ = 0; i$ < len$; ++i$) {
			File aFile = arr$[i$];
			int aCounter = extractCounter(aFile, stemRegex);
			if (max < aCounter) {
				max = aCounter;
			}
		}

		return max;
	}

	public static int extractCounter(File file, String stemRegex) {
		Pattern p = Pattern.compile(stemRegex);
		String lastFileName = file.getName();
		Matcher m = p.matcher(lastFileName);
		if (!m.matches()) {
			throw new IllegalStateException("The regex [" + stemRegex + "] should match [" + lastFileName + "]");
		} else {
			String counterAsStr = m.group(1);
			return new Integer(counterAsStr);
		}
	}

	public static String slashify(String in) {
		return in.replace('\\', '/');
	}

	public static void removeEmptyParentDirectories(File file, int recursivityCount) {
		if (recursivityCount < 3) {
			File parent = file.getParentFile();
			if (parent.isDirectory() && isEmptyDirectory(parent)) {
				parent.delete();
				removeEmptyParentDirectories(parent, recursivityCount + 1);
			}

		}
	}
}