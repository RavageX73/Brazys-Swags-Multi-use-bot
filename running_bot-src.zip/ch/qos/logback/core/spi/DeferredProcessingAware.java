package ch.qos.logback.core.spi;

public interface DeferredProcessingAware {
	void prepareForDeferredProcessing();
}