package ch.qos.logback.core.spi;

public class LogbackLock {
}