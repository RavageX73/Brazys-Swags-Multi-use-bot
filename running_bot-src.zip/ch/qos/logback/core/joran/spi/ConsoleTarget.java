package ch.qos.logback.core.joran.spi;

import ch.qos.logback.core.joran.spi.ConsoleTarget.1;
import ch.qos.logback.core.joran.spi.ConsoleTarget.2;
import java.io.OutputStream;

public enum ConsoleTarget {
   SystemOut("System.out", new 1()),
   SystemErr("System.err", new 2());

   private final String name;
   private final OutputStream stream;

   public static ConsoleTarget findByName(String name) {
      ConsoleTarget[] arr$ = values();
      int len$ = arr$.length;

      for(int i$ = 0; i$ < len$; ++i$) {
         ConsoleTarget target = arr$[i$];
         if (target.name.equalsIgnoreCase(name)) {
            return target;
         }
      }

      return null;
   }

   private ConsoleTarget(String name, OutputStream stream) {
      this.name = name;
      this.stream = stream;
   }

   public String getName() {
      return this.name;
   }

   public OutputStream getStream() {
      return this.stream;
   }

   public String toString() {
      return this.name;
   }
}