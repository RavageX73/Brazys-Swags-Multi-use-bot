package ch.qos.logback.core.joran.event;

public interface InPlayListener {
	void inPlay(SaxEvent var1);
}