package ch.qos.logback.core.joran.conditional;

public interface Condition {
	boolean evaluate();
}