package ch.qos.logback.core.status;

public class NopStatusListener implements StatusListener {
	public void addStatusEvent(Status status) {
	}
}