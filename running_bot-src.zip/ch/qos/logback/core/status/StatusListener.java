package ch.qos.logback.core.status;

public interface StatusListener {
	void addStatusEvent(Status var1);
}