package ch.qos.logback.core.db.dialect;

public interface SQLDialect {
	String getSelectInsertId();
}