package ch.qos.logback.core.db.dialect;

import ch.qos.logback.core.db.dialect.DBUtil.1;
import ch.qos.logback.core.spi.ContextAwareBase;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public class DBUtil extends ContextAwareBase {
	private static final String POSTGRES_PART = "postgresql";
	private static final String MYSQL_PART = "mysql";
	private static final String ORACLE_PART = "oracle";
	private static final String MSSQL_PART = "microsoft";
	private static final String HSQL_PART = "hsql";
	private static final String H2_PART = "h2";
	private static final String SYBASE_SQLANY_PART = "sql anywhere";
	private static final String SQLITE_PART = "sqlite";

	public static SQLDialectCode discoverSQLDialect(DatabaseMetaData meta) {
		SQLDialectCode dialectCode = SQLDialectCode.UNKNOWN_DIALECT;

		try {
			String dbName = meta.getDatabaseProductName().toLowerCase();
			if (dbName.indexOf("postgresql") != -1) {
				return SQLDialectCode.POSTGRES_DIALECT;
			} else if (dbName.indexOf("mysql") != -1) {
				return SQLDialectCode.MYSQL_DIALECT;
			} else if (dbName.indexOf("oracle") != -1) {
				return SQLDialectCode.ORACLE_DIALECT;
			} else if (dbName.indexOf("microsoft") != -1) {
				return SQLDialectCode.MSSQL_DIALECT;
			} else if (dbName.indexOf("hsql") != -1) {
				return SQLDialectCode.HSQL_DIALECT;
			} else if (dbName.indexOf("h2") != -1) {
				return SQLDialectCode.H2_DIALECT;
			} else if (dbName.indexOf("sql anywhere") != -1) {
				return SQLDialectCode.SYBASE_SQLANYWHERE_DIALECT;
			} else {
				return dbName.indexOf("sqlite") != -1 ? SQLDialectCode.SQLITE_DIALECT : SQLDialectCode.UNKNOWN_DIALECT;
			}
		} catch (SQLException var3) {
			return dialectCode;
		}
	}

	public static SQLDialect getDialectFromCode(SQLDialectCode sqlDialectType) {
      SQLDialect sqlDialect = null;
      switch(1.$SwitchMap$ch$qos$logback$core$db$dialect$SQLDialectCode[sqlDialectType.ordinal()]) {
      case 1:
         sqlDialect = new PostgreSQLDialect();
         break;
      case 2:
         sqlDialect = new MySQLDialect();
         break;
      case 3:
         sqlDialect = new OracleDialect();
         break;
      case 4:
         sqlDialect = new MsSQLDialect();
         break;
      case 5:
         sqlDialect = new HSQLDBDialect();
         break;
      case 6:
         sqlDialect = new H2Dialect();
         break;
      case 7:
         sqlDialect = new SybaseSqlAnywhereDialect();
         break;
      case 8:
         sqlDialect = new SQLiteDialect();
      }

      return (SQLDialect)sqlDialect;
   }

	public boolean supportsGetGeneratedKeys(DatabaseMetaData meta) {
		try {
			return (Boolean) DatabaseMetaData.class.getMethod("supportsGetGeneratedKeys", (Class[]) null).invoke(meta,
					(Object[]) null);
		} catch (Throwable var3) {
			this.addInfo("Could not call supportsGetGeneratedKeys method. This may be recoverable");
			return false;
		}
	}

	public boolean supportsBatchUpdates(DatabaseMetaData meta) {
		try {
			return meta.supportsBatchUpdates();
		} catch (Throwable var3) {
			this.addInfo("Missing DatabaseMetaData.supportsBatchUpdates method.");
			return false;
		}
	}
}