package ch.qos.logback.core.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DriverManagerConnectionSource extends ConnectionSourceBase {
	private String driverClass = null;
	private String url = null;

	public void start() {
		try {
			if (this.driverClass != null) {
				Class.forName(this.driverClass);
				this.discoverConnectionProperties();
			} else {
				this.addError("WARNING: No JDBC driver specified for logback DriverManagerConnectionSource.");
			}
		} catch (ClassNotFoundException var2) {
			this.addError("Could not load JDBC driver class: " + this.driverClass, var2);
		}

	}

	public Connection getConnection() throws SQLException {
		return this.getUser() == null
				? DriverManager.getConnection(this.url)
				: DriverManager.getConnection(this.url, this.getUser(), this.getPassword());
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDriverClass() {
		return this.driverClass;
	}

	public void setDriverClass(String driverClass) {
		this.driverClass = driverClass;
	}
}