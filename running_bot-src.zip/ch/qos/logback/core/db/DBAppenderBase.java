package ch.qos.logback.core.db;

import ch.qos.logback.core.UnsynchronizedAppenderBase;
import ch.qos.logback.core.db.dialect.DBUtil;
import ch.qos.logback.core.db.dialect.SQLDialect;
import ch.qos.logback.core.db.dialect.SQLDialectCode;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class DBAppenderBase<E> extends UnsynchronizedAppenderBase<E> {
	protected ConnectionSource connectionSource;
	protected boolean cnxSupportsGetGeneratedKeys = false;
	protected boolean cnxSupportsBatchUpdates = false;
	protected SQLDialect sqlDialect;

	protected abstract Method getGeneratedKeysMethod();

	protected abstract String getInsertSQL();

	public void start() {
		if (this.connectionSource == null) {
			throw new IllegalStateException("DBAppender cannot function without a connection source");
		} else {
			this.sqlDialect = DBUtil.getDialectFromCode(this.connectionSource.getSQLDialectCode());
			if (this.getGeneratedKeysMethod() != null) {
				this.cnxSupportsGetGeneratedKeys = this.connectionSource.supportsGetGeneratedKeys();
			} else {
				this.cnxSupportsGetGeneratedKeys = false;
			}

			this.cnxSupportsBatchUpdates = this.connectionSource.supportsBatchUpdates();
			if (!this.cnxSupportsGetGeneratedKeys && this.sqlDialect == null) {
				throw new IllegalStateException(
						"DBAppender cannot function if the JDBC driver does not support getGeneratedKeys method *and* without a specific SQL dialect");
			} else {
				super.start();
			}
		}
	}

	public ConnectionSource getConnectionSource() {
		return this.connectionSource;
	}

	public void setConnectionSource(ConnectionSource connectionSource) {
		this.connectionSource = connectionSource;
	}

	public void append(E eventObject) {
		Connection connection = null;
		PreparedStatement insertStatement = null;

		try {
			connection = this.connectionSource.getConnection();
			connection.setAutoCommit(false);
			if (this.cnxSupportsGetGeneratedKeys) {
				String EVENT_ID_COL_NAME = "EVENT_ID";
				if (this.connectionSource.getSQLDialectCode() == SQLDialectCode.POSTGRES_DIALECT) {
					EVENT_ID_COL_NAME = EVENT_ID_COL_NAME.toLowerCase();
				}

				insertStatement = connection.prepareStatement(this.getInsertSQL(), new String[]{EVENT_ID_COL_NAME});
			} else {
				insertStatement = connection.prepareStatement(this.getInsertSQL());
			}

			long eventId;
			synchronized (this) {
				this.subAppend(eventObject, connection, insertStatement);
				eventId = this.selectEventId(insertStatement, connection);
			}

			this.secondarySubAppend(eventObject, connection, eventId);
			connection.commit();
		} catch (Throwable var13) {
			this.addError("problem appending event", var13);
		} finally {
			DBHelper.closeStatement(insertStatement);
			DBHelper.closeConnection(connection);
		}

	}

	protected abstract void subAppend(E var1, Connection var2, PreparedStatement var3) throws Throwable;

	protected abstract void secondarySubAppend(E var1, Connection var2, long var3) throws Throwable;

	protected long selectEventId(PreparedStatement insertStatement, Connection connection)
			throws SQLException, InvocationTargetException {
		ResultSet rs = null;
		Statement idStatement = null;

		long var8;
		try {
			boolean gotGeneratedKeys = false;
			if (this.cnxSupportsGetGeneratedKeys) {
				try {
					rs = (ResultSet) this.getGeneratedKeysMethod().invoke(insertStatement, (Object[]) null);
					gotGeneratedKeys = true;
				} catch (InvocationTargetException var19) {
					Throwable target = var19.getTargetException();
					if (target instanceof SQLException) {
						throw (SQLException) target;
					}

					throw var19;
				} catch (IllegalAccessException var20) {
					this.addWarn("IllegalAccessException invoking PreparedStatement.getGeneratedKeys", var20);
				}
			}

			if (!gotGeneratedKeys) {
				idStatement = connection.createStatement();
				idStatement.setMaxRows(1);
				String selectInsertIdStr = this.sqlDialect.getSelectInsertId();
				rs = idStatement.executeQuery(selectInsertIdStr);
			}

			rs.next();
			long eventId = rs.getLong(1);
			var8 = eventId;
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException var18) {
					;
				}
			}

			DBHelper.closeStatement(idStatement);
		}

		return var8;
	}

	public void stop() {
		super.stop();
	}
}