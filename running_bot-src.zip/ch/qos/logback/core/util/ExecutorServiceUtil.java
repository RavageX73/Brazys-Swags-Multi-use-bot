package ch.qos.logback.core.util;

import ch.qos.logback.core.util.ExecutorServiceUtil.1;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ExecutorServiceUtil {
	private static final ThreadFactory THREAD_FACTORY = new 1();

	public static ScheduledExecutorService newScheduledExecutorService() {
		return new ScheduledThreadPoolExecutor(8, THREAD_FACTORY);
	}

	public static ExecutorService newExecutorService() {
		return new ThreadPoolExecutor(0, 32, 0L, TimeUnit.MILLISECONDS, new SynchronousQueue(), THREAD_FACTORY);
	}

	public static void shutdown(ExecutorService executorService) {
		executorService.shutdownNow();
	}
}