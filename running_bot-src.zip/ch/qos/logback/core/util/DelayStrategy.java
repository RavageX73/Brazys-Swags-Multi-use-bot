package ch.qos.logback.core.util;

public interface DelayStrategy {
	long nextDelay();
}