package ch.qos.logback.core.html;

public class NOPThrowableRenderer implements IThrowableRenderer {
	public void render(StringBuilder sbuf, Object event) {
	}
}