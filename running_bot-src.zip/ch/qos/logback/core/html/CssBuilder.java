package ch.qos.logback.core.html;

public interface CssBuilder {
	void addCss(StringBuilder var1);
}