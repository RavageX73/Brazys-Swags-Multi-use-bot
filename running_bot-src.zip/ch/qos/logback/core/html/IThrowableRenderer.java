package ch.qos.logback.core.html;

public interface IThrowableRenderer<E> {
	void render(StringBuilder var1, E var2);
}