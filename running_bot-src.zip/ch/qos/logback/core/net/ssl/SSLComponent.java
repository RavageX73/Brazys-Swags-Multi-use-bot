package ch.qos.logback.core.net.ssl;

public interface SSLComponent {
	SSLConfiguration getSsl();

	void setSsl(SSLConfiguration var1);
}