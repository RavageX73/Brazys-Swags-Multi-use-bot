package ch.qos.logback.core.net;

import ch.qos.logback.core.net.DefaultSocketConnector.1;
import ch.qos.logback.core.net.DefaultSocketConnector.ConsoleExceptionHandler;
import ch.qos.logback.core.net.SocketConnector.ExceptionHandler;
import ch.qos.logback.core.util.DelayStrategy;
import ch.qos.logback.core.util.FixedDelay;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.SocketFactory;

public class DefaultSocketConnector implements SocketConnector {
	private final InetAddress address;
	private final int port;
	private final DelayStrategy delayStrategy;
	private ExceptionHandler exceptionHandler;
	private SocketFactory socketFactory;

	public DefaultSocketConnector(InetAddress address, int port, long initialDelay, long retryDelay) {
		this(address, port, new FixedDelay(initialDelay, retryDelay));
	}

	public DefaultSocketConnector(InetAddress address, int port, DelayStrategy delayStrategy) {
		this.address = address;
		this.port = port;
		this.delayStrategy = delayStrategy;
	}

	public Socket call() throws InterruptedException {
		this.useDefaultsForMissingFields();

		Socket socket;
		for (socket = this.createSocket(); socket == null
				&& !Thread.currentThread().isInterrupted(); socket = this.createSocket()) {
			Thread.sleep(this.delayStrategy.nextDelay());
		}

		return socket;
	}

	private Socket createSocket() {
		Socket newSocket = null;

		try {
			newSocket = this.socketFactory.createSocket(this.address, this.port);
		} catch (IOException var3) {
			this.exceptionHandler.connectionFailed(this, var3);
		}

		return newSocket;
	}

	private void useDefaultsForMissingFields() {
      if (this.exceptionHandler == null) {
         this.exceptionHandler = new ConsoleExceptionHandler((1)null);
      }

      if (this.socketFactory == null) {
         this.socketFactory = SocketFactory.getDefault();
      }

   }

	public void setExceptionHandler(ExceptionHandler exceptionHandler) {
		this.exceptionHandler = exceptionHandler;
	}

	public void setSocketFactory(SocketFactory socketFactory) {
		this.socketFactory = socketFactory;
	}
}