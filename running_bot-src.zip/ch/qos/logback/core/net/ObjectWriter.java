package ch.qos.logback.core.net;

import java.io.IOException;

public interface ObjectWriter {
	void write(Object var1) throws IOException;
}