package ch.qos.logback.core.net;

import ch.qos.logback.core.net.SocketConnector.ExceptionHandler;
import java.net.Socket;
import java.util.concurrent.Callable;
import javax.net.SocketFactory;

public interface SocketConnector extends Callable<Socket> {
	Socket call() throws InterruptedException;

	void setExceptionHandler(ExceptionHandler var1);

	void setSocketFactory(SocketFactory var1);
}