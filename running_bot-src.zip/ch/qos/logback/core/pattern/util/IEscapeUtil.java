package ch.qos.logback.core.pattern.util;

public interface IEscapeUtil {
	void escape(String var1, StringBuffer var2, char var3, int var4);
}